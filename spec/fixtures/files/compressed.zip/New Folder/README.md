The file `example__Tiles.sqlite3` is an example container
format used by the output of the zooming spectrograms analysis.

It is a **small** version that has been heavily modified to be
useful in a variety of unit tests. The true files do not have
"sub directories" in them.

It contains:

- `/BLENDED.Tile_20160727T110000Z_120.png`
- `/BLENDED.Tile_20160727T110000Z_240.png`
- `/BLENDED.Tile_20160727T110000Z_60.png`
- `/sub_dir_1/BLENDED.Tile_20160727T122624Z_3.2.png`
- `/BLENDED.Tile_20160727T123000Z_15.png`
- `/BLENDED.Tile_20160727T123000Z_30.png`
- `/sub_dir_2/BLENDED.Tile_20160727T123000Z_7.5.png`
- `/sub_dir_1/BLENDED.Tile_20160727T123600Z_3.2.png`
- `/sub_dir_1/BLENDED.Tile_20160727T124536Z_3.2.png`
- `/sub_dir_2/BLENDED.Tile_20160727T125230Z_7.5.png`